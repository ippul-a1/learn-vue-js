<template>
  <!-- <form action=""> -->  
  <form v-on:submit.prevent="submitForm">    
    <div>
      <label for="username">id:</label>
      <input id="username" type="text" v-model="username">
    </div>
    <div>
      <label for="password">pw:</label>
      <input id="password" type="text" v-model="password"> 
    </div>

    <button type="submit">login</button>

  </form>
</template>

<script>
import axios from 'axios';

export default {
  data :function(){
    return {
      username :'',
      password :''
    }
  },
  methods : {
    submitForm : function(){          
      console.log(this.username, this.password);
      // var url = 'https://jsonplaceholder.typicode.com/todos/1';
      var url = 'https://jsonplaceholder.typicode.com/users';
      var data = {
        username : this.username,
        password : this.password
      }
      axios.post(url, data)
      .then(function(response) {
         console.log(response);
         
      })
      .catch(function(error){
        console.log(error);

      });
    }

    // submitForm : function(event){      
    //   event.preventDefault(); // form의 기본동작인 새로고침이 안되도록 하는 메서드 => 위 form 에 .prevent 를 붙이면 같은 동작을 함.
    //   console.log(this.username, this.password);
    // }
  }
}
</script>

<style>

</style>