<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/logo.png">
    <HelloWorld msg="Welcome to Your Vue.js App"/>
<!-- 컴포넌트 명명법 종류
    <hello-world></hello-world>
    <HelloWorld></HelloWorld>
    <HelloWorld/> 
  -->
  </div>
</template>

<script>
import HelloWorld from './components/HelloWorld_old.vue'

export default {
  // 인스턴스 옵션 속성 or 컴포넌트 옵셧 속성
  name: 'App',
  components: {
    HelloWorld
    // 'hello-world' : HelloWorld 와 동일
  }
}

// export default => 아래와 동일
// new Vue({
// name: 'App',
//   components: {
//     HelloWorld
//     // 'hello-world' : HelloWorld 와 동일
//   }
// })

</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
