// sfc(single file component) or vue(2.x버전)
<template>
  <!-- html -->
  <!-- 하나의 요소만 사용한다 -->
  <div>header</div>
</template>

<script>
export default {
// javascript -인스턴스 옵션
    methods : {
        addnum : function(){
            
        }
    }
}
</script>

<style>
/* css */
</style>

// // 아래처럼 작성되었던 것이 vue 에서는 위와 같이 나뉘어 들어감
// var appHeader = {
//     template : '<div>header</div>',
//     methods : {
//         addnum : function(){

//         }
//     }
// }