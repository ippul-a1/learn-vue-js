<template>
  <!-- 하나의 요소만 사용한다 -->
  <div>
    <!-- app -->
    {{ str }}
    <!-- <app-header v-bind:프롭스 속성 이름="상위 컴포넌트의 데이터(data) 이름"></app-header> -->
    <app-header 
        v-bind:propsdata="str"
        v-on:renew="renewStr" ></app-header>
  </div>
</template>

<script>
import AppHeader from './components/AppHeader.vue';

export default {
    data : function(){
        return {
            // str : 'hi'
            str : 'Header'
        }
    },
    components :{
        'app-header' : AppHeader
    },
    methods : {
        renewStr : function(){
            this.str = 'hi';
        }
    }
}

// var AppHeader = {
//     template : <header><h1>Header</h1></header>
// }
// new Vue({
//     data :{
//         str : 'hi'
//     }
//       components :{
//        'app-header' : AppHeader
//    }
// })



</script>

<style>

</style>
