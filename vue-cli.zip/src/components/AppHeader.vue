<template>
  <header>
    <!-- <h1>Header</h1> -->
    <!-- 화면에서 입력된 데이타가 바로 반영됨, reactivity -->
    <h1>{{propsdata}}</h1>
    <!-- 버튼 클릭시 화면에 데이타가 변경됨 -->
    <button v-on:click="sendEvent">send</button>
  </header>

</template>

<script>
export default {
    props : ['propsdata'],
    methods : {
        sendEvent : function(){
            this.$emit('renew');
        }
    }
}
</script>

<style>

</style>