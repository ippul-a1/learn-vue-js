import Vue from 'vue'
import App from './App.vue'

Vue.config.productionTip = false

new Vue({
  render: h => h(App)
}).$mount('#app')


// 아래와 동일
// var App = {
//   template : <div>app</div>
// }

// new Vue({
//   el : '#app',
//   componets : {
//       'app' : APP
//  } =>  render: h => h(App) 와 동일
// })